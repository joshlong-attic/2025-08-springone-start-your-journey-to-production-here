package com.example.deskcheck1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Deskcheck1Application {

	public static void main(String[] args) {
		SpringApplication.run(Deskcheck1Application.class, args);
	}

}
