package com.example.deskcheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeskcheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeskcheckApplication.class, args);
	}

}
